<?php
/**
 * Cart Controller
 */

class CartController
{

    public function checkout(): void
    {
        view('public/checkout');
    }
}
